<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Domaci broj 9</title>
    <style>
    body {
        font-size: 1.4em;
        text-align: center;
        background-color: darkgray;
    }
    </style>
</head>
<body>
    <?php
    
    $boja = "lkdjfogidj";

    switch($boja) {
        case "red":
            echo "<p style='color: red'>Crvena</p>";
            break;

        case "green":
            echo "<p style='color: green'>Zelena</p>";
            break;

        case "blue":
            echo "<p style='color: blue'>Plava</p>";
            break;

        default:
            echo "<p style='color: yellow'>Niste uneli ni crvenu, ni zelenu, a ni plavu.</p>";
    }
    
    
    ?>
</body>
</html>